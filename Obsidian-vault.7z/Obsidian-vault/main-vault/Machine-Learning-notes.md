# 1st Lesson
## what is machine learning
machine learning is when computers learn from data instead of manually or being explicitly programmed

 **Features** are the input variables or signals you feed into a machine learning model so it can learn patterns.
They are **the known information** the model uses to make predictions.

A **label** is the target output you want the model to learn to predict — the "answer" associated with each set of features.

Whats a model

| Model                                                           |
| --------------------------------------------------------------- |
| A learned function that maps input features to predicted labels |
